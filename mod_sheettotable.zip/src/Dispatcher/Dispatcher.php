<?php
/**
 * @package                                     <mod_sheettotable>
 *
 * @author                                      <MyCompany> | <Me> <email>
 * @copyright                                   Copyright(R) year by  <MyCompany> | <Me>
 * @license                                     GNU General Public License version 2 or later; see LICENSE.txt
 * @link                                        <mywebsite>
 * @since                                       1.0.0
 *
 */

namespace My\Module\sheettotable\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;
use My\Module\sheettotable\Site\Helper\sheettotableHelper;

class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    protected function getLayoutData()
    {
    // Get the module Parameters
        $params = new Registry($this->module->params);
        $data          = parent::getLayoutData();

        $helperName    = 'sheettotableHelper';
        $data['mymsg'] = $this->getHelperFactory()->getHelper($helperName)->getMessage($data['params'], $this->getApplication());
        return $data;
    }
}