 <?php
defined('_JEXEC') or die;

require_once __DIR__ . '/helper.php';

$items = ModSheetToTableHelper::getItems($params);

require JModuleHelper::getLayoutPath('mod_sheettotable', $params->get('layout', 'default'));