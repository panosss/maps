<?php
/**
 * @package                                     <mod_example>
 *
 * @author                                      <MyCompany> | <Me> <email>
 * @copyright                                   Copyright(R) year by  <MyCompany> | <Me>
 * @license                                     GNU General Public License version 2 or later; see LICENSE.txt
 * @link                                        <mywebsite>
 * @since                                       1.0.0
 *
 * @var     $module     \Joomla\CMS\Module\Module   The module object
 * @var     $params     \Joomla\Registry\Registry   The module params
 * @var     $mymsg     string                       The String that has been noted in the module settings and has been stored in the data array in our Dispatcher
 *
 */

defined('_JEXEC') or die;

echo '<h1>' . $mymsg . '</h1>';