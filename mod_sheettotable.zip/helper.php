 <?php
defined('_JEXEC') or die;

class ModSheetToTableHelper
{
    public static function getItems($params)
    {
        $db = JFactory::getDbo();

        $query = trim($params->get('custom_sql', ''));
        if (!$query) return [];

        // Έλεγχος: Επιτρέπεται μόνο SELECT queries
        if (stripos($query, 'select') !== 0) return [];

        try {
            $db->setQuery($query);
            return $db->loadObjectList();
        } catch (Exception $e) {
            return [];
        }
    }
}