 <?php defined('_JEXEC') or die; ?>
<div id="mod-sheettotable-<?php echo $module->id; ?>">
    <div class="table-responsive">
        <?php if (!empty($items)) : ?>
            <table class="table table-striped table-bordered mydb-table">
                <thead>
                    <tr>
                        <?php foreach (array_keys(get_object_vars($items[0])) as $colName) : ?>
                            <th><?php echo htmlspecialchars($colName, ENT_QUOTES, 'UTF-8'); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item) : ?>
                        <tr>
                            <?php foreach ($item as $value) : ?>
                                <td><?php echo htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>Δεν βρέθηκαν δεδομένα.</p>
        <?php endif; ?>
    </div>

    <?php if ($params->get('custom_css')) : ?>
        <style>
            #mod-sheettotable-<?php echo $module->id; ?> {
                <?php echo $params->get('custom_css'); ?>
            }
        </style>
    <?php endif; ?>
</div>